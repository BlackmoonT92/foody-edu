package com.itschool.checongbinh.foody.Controller.Interfaces;

import com.itschool.checongbinh.foody.Model.QuanAnModel;

import java.util.List;

/**
 * Created by Binh on 4/17/17.
 */

public interface OdauInterface {
    void getDanhSachQuanAnModel(QuanAnModel quanAnModel);
}
