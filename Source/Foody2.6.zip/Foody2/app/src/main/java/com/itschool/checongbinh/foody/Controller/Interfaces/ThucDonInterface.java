package com.itschool.checongbinh.foody.Controller.Interfaces;

import com.itschool.checongbinh.foody.Model.ThucDonModel;

import java.util.List;

/**
 * Created by Binh on 7/10/17.
 */

public interface ThucDonInterface {
    public void getThucDonThanhCong(List<ThucDonModel> thucDonModelList);
}
