package com.itschool.checongbinh.foody.Model;

import java.util.List;

/**
 * Created by Binh on 8/18/17.
 */

public class ThemThucDonModel {
    String mathucdon;
    MonAnModel monAnModel;

    public MonAnModel getMonAnModel() {
        return monAnModel;
    }

    public void setMonAnModel(MonAnModel monAnModel) {
        this.monAnModel = monAnModel;
    }



    public String getMathucdon() {
        return mathucdon;
    }

    public void setMathucdon(String mathucdon) {
        this.mathucdon = mathucdon;
    }


}
