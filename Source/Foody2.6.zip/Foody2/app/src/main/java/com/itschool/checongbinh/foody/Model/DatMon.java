package com.itschool.checongbinh.foody.Model;

/**
 * Created by Binh on 8/1/17.
 */

public class DatMon {
    public String getTenMonAn() {
        return tenMonAn;
    }

    public void setTenMonAn(String tenMonAn) {
        this.tenMonAn = tenMonAn;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    String tenMonAn;
    int soLuong;
}
