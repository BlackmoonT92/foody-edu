package com.itschool.checongbinh.foody.Controller.Interfaces;

import com.itschool.checongbinh.foody.Model.WifiQuanAnModel;

/**
 * Created by Binh on 5/14/17.
 */

public interface ChiTietQuanAnInterface {
    void HienThiDanhSachWifi(WifiQuanAnModel wifiQuanAnModel);
}
